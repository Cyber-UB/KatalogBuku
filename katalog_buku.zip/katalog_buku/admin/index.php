<!DOCTYPE html>
<html>
<?php

use kcfinder\session;

session_start() ?>

<head>
  <link rel="stylesheet" href="dist/style.css">

  <?php include("includes/head.php") ?>
</head>

<body>

  <!-- /.login-logo -->
  <div class="container-login">

    <div class="wrap-login">

      <div class="login-logo">
        <a href="#"><b>Admin</b>Katalog Buku</a>
      </div>
      <p class="login-box-msg">Sign in to start your session</p>

      <?php if (!empty($_GET['gagal'])) { ?>
        <?php if ($_GET['gagal'] == "userKosong") { ?>
          <span class="text-danger"> Maaf Username Tidak Boleh Kosong </span>
        <?php } else if ($_GET['gagal'] == "passKosong") { ?>
          <span class="text-danger"> Maaf Password Tidak Boleh Kosong </span>
        <?php } else { ?>
          <span class="text-danger"> Maaf Username dan Password Anda Salah </span>
        <?php } ?>
      <?php } ?>
      <form action="konfirmasilogin.php" method="post">
        <div class="input-group mb-2">
          <input type="text" class="form-control" name="username" placeholder="Username">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>

        <div class="input-group mb-3">
          <input type="password" class="form-control" name="password" placeholder="Password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
          </div>
          <!-- /.col -->
          <div class="col-4">
            <div class="container-login-form-btn">
              <div class="wrap-login-form-btn">
                <div class="login-form-bgbtn"></div>
                <button type="submit" name="login" value="login" class="btn btn-primary btn-block">Sign In</button>
      </form>
      </nav>
    </div>
  </div>
  </div>
  </div>
  </div>
  <script src="plugins/jquery/jquery.js"></script>
  <script src="plugins/bootstrap/js/bootstrap.min.js"></script>
  </main>
  <?php include("includes/script.php") ?>

</body>

</html>